import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Moon, Sun, Menu, X, Github, Linkedin, Instagram, ArrowUpRight, Sparkles, MapPin, Cake, GraduationCap, Laptop, Code2, Server, Palette } from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import photo from "@/assets/julia.jpeg.asset.json";
import { projects } from "@/data/projects";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Julia Gabriela Cariaga — Portfólio" },
      { name: "description", content: "Portfólio de Julia Gabriela Cariaga, estudante de Tecnologia da Informação e desenvolvedora em formação em Campinas — SP." },
      { property: "og:title", content: "Julia Gabriela Cariaga — Portfólio" },
      { property: "og:description", content: "Transformando criatividade em ideias e ideias em experiências digitais." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const nav = [
  ["inicio", "Início"],
  ["sobre", "Sobre mim"],
  ["habilidades", "Habilidades"],
  ["projetos", "Projetos"],
  ["contato", "Contato"],
] as const;

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("is-visible")),
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };
  return (
    <button onClick={toggle} aria-label="Alternar tema" className="grid h-10 w-10 place-items-center rounded-full border border-gold/50 text-gold transition hover:rotate-12 hover:bg-accent">
      {dark ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}

function SectionTitle({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="reveal mb-14 text-center">
      <p className="mb-3 text-xs uppercase tracking-[0.35em] text-gold">{eyebrow}</p>
      <h2 className="text-4xl font-medium md:text-6xl">{title}</h2>
      <div className="mx-auto mt-5 flex items-center justify-center gap-3">
        <span className="h-px w-12 bg-gold/60" />
        <Sparkles size={14} className="text-primary" />
        <span className="h-px w-12 bg-gold/60" />
      </div>
    </div>
  );
}

function Index() {
  useReveal();
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    setSending(true);
    setTimeout(() => {
      setSending(false);
      form.reset();
      toast.success("Mensagem enviada! Obrigada pelo contato 💕");
    }, 700);
  };

  const skills = [
    { icon: Code2, title: "Front-End", items: ["HTML5", "CSS3", "JavaScript", "Criação de páginas web", "Desenvolvimento de interfaces"] },
    { icon: Server, title: "Back-End", items: ["Lógica de programação", "Fundamentos de programação", "Conhecimentos iniciais de Back-End"] },
    { icon: Palette, title: "Design e criatividade", items: ["Organização visual", "Criação de layouts", "Identidade visual", "Edição e composição de imagens"] },
  ];

  return (
    <div className="min-h-screen overflow-x-hidden">
      <Toaster />
      <header className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/75 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <a href="#inicio" className="font-display text-2xl italic">
            Julia<span className="text-gold">.</span>
          </a>
          <nav className="hidden gap-8 md:flex">
            {nav.map(([id, label]) => (
              <a key={id} href={`#${id}`} className="text-sm tracking-wide text-muted-foreground transition hover:text-primary">{label}</a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button>
          </div>
        </div>
        {open && (
          <nav className="flex flex-col gap-4 border-t border-border px-6 py-5 md:hidden">
            {nav.map(([id, label]) => (
              <a key={id} href={`#${id}`} onClick={() => setOpen(false)} className="text-muted-foreground hover:text-primary">{label}</a>
            ))}
          </nav>
        )}
      </header>

      {/* Início */}
      <section id="inicio" className="bg-hero relative flex min-h-screen items-center pt-24">
        <Sparkles className="float-slow absolute left-[8%] top-[22%] text-gold/70" size={28} />
        <span className="float-slow absolute bottom-[18%] right-[10%] h-24 w-24 rounded-full border border-gold/40" />
        <div className="mx-auto grid max-w-6xl items-center gap-14 px-6 md:grid-cols-[1.2fr_1fr]">
          <div className="reveal">
            <p className="mb-6 text-xs uppercase tracking-[0.4em] text-gold">Portfólio · 2026</p>
            <h1 className="text-6xl leading-[0.95] font-medium md:text-8xl">
              Julia Gabriela <em className="text-primary">Cariaga</em>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">Estudante de Tecnologia da Informação | Desenvolvedora em formação.</p>
            <p className="mt-6 border-l-2 border-gold pl-4 font-display text-2xl italic">
              "Transformando criatividade em ideias e ideias em experiências digitais."
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a href="#projetos" className="shadow-soft rounded-full bg-primary px-7 py-3.5 text-sm font-medium text-primary-foreground transition hover:-translate-y-0.5">Conheça meus projetos</a>
              <a href="#contato" className="rounded-full border border-gold px-7 py-3.5 text-sm font-medium transition hover:-translate-y-0.5 hover:bg-accent">Entre em contato</a>
            </div>
          </div>
          <div className="reveal relative mx-auto w-full max-w-sm">
            <div className="absolute -inset-4 rounded-t-full border border-gold/60" />
            <div className="absolute -right-6 -bottom-6 h-full w-full rounded-t-full bg-blush" />
            <img src={photo.url} alt="Julia Gabriela Cariaga" className="relative aspect-[3/4] w-full rounded-t-full object-cover shadow-soft" />
          </div>
        </div>
      </section>

      {/* Sobre */}
      <section id="sobre" className="py-28">
        <div className="mx-auto max-w-5xl px-6">
          <SectionTitle eyebrow="Sobre mim" title="Um pouco sobre mim." />
          <div className="reveal space-y-5 text-center text-lg leading-relaxed text-muted-foreground">
            <p>Meu nome é <strong className="text-foreground">Julia Gabriela Cariaga</strong>, tenho 16 anos e moro em Campinas, São Paulo. Atualmente, estou cursando o segundo ano do Ensino Médio integrado ao curso técnico de Tecnologia da Informação.</p>
            <p>Tenho interesse pela área de tecnologia, programação e desenvolvimento de projetos digitais. Durante minha formação, venho aprendendo novas ferramentas, desenvolvendo minha criatividade e aprimorando minhas habilidades para transformar ideias em projetos.</p>
            <p>Quero continuar aprendendo, adquirindo experiências e descobrindo novas possibilidades dentro do universo da tecnologia.</p>
          </div>
          <div className="mt-14 grid grid-cols-2 gap-4 md:grid-cols-4">
            {[[Cake, "16 anos"], [MapPin, "Campinas — SP"], [GraduationCap, "2º ano do Ensino Médio"], [Laptop, "Técnico em TI"]].map(([Icon, text], i) => {
              const I = Icon as typeof Cake;
              return (
                <div key={i} className="reveal rounded-2xl border border-border bg-card p-6 text-center transition hover:-translate-y-1 hover:border-gold" style={{ transitionDelay: `${i * 80}ms` }}>
                  <I className="mx-auto mb-3 text-gold" size={22} />
                  <p className="text-sm font-medium">{text as string}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Habilidades */}
      <section id="habilidades" className="bg-muted/50 py-28">
        <div className="mx-auto max-w-6xl px-6">
          <SectionTitle eyebrow="Conhecimentos em desenvolvimento" title="Minhas habilidades" />
          <div className="grid gap-6 md:grid-cols-3">
            {skills.map(({ icon: Icon, title, items }, i) => (
              <div key={title} className="reveal group rounded-3xl border border-border bg-card p-8 transition hover:-translate-y-1 hover:shadow-soft" style={{ transitionDelay: `${i * 100}ms` }}>
                <div className="mb-6 grid h-12 w-12 place-items-center rounded-full bg-accent text-primary transition group-hover:rotate-12"><Icon size={22} /></div>
                <h3 className="mb-5 text-3xl">{title}</h3>
                <ul className="flex flex-wrap gap-2">
                  {items.map((s) => (
                    <li key={s} className="rounded-full border border-gold/40 px-3 py-1 text-sm text-muted-foreground">{s}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projetos */}
      <section id="projetos" className="py-28">
        <div className="mx-auto max-w-6xl px-6">
          <SectionTitle eyebrow="Portfólio" title="Projetos que desenvolvi." />
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((p) => (
              <article key={p.number} className="reveal group flex flex-col overflow-hidden rounded-3xl border border-border bg-card transition duration-500 hover:-translate-y-2 hover:shadow-soft">
                <div className="relative overflow-hidden">
                  <img src={p.image} alt={p.title} loading="lazy" width={1024} height={768} className="aspect-[4/3] w-full object-cover transition duration-700 group-hover:scale-105" />
                  <span className="absolute left-4 top-4 rounded-full bg-background/85 px-3 py-1 text-xs font-medium backdrop-blur">{p.tag}</span>
                </div>
                <div className="flex flex-1 flex-col p-7">
                  <p className="text-gold-gradient font-display text-xl italic">Projeto {p.number}</p>
                  <h3 className="mt-1 text-2xl font-semibold">{p.title}</h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {p.tech.map((t) => <span key={t} className="rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground">{t}</span>)}
                  </div>
                  {p.link ? (
                    <a href={p.link} target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">Ver projeto <ArrowUpRight size={16} /></a>
                  ) : (
                    <span className="mt-6 text-xs uppercase tracking-widest text-muted-foreground">Link em breve</span>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Contato */}
      <section id="contato" className="bg-hero py-28">
        <div className="mx-auto max-w-3xl px-6">
          <SectionTitle eyebrow="Contato" title="Vamos conversar?" />
          <p className="reveal mb-10 text-center text-lg text-muted-foreground">Gostou dos meus projetos ou quer trocar uma ideia? Entre em contato comigo!</p>
          <form onSubmit={onSubmit} className="reveal space-y-4 rounded-3xl border border-border bg-card p-8 shadow-soft">
            <div className="grid gap-4 md:grid-cols-2">
              <input required name="nome" placeholder="Seu nome" maxLength={100} className="rounded-xl border border-input bg-background px-4 py-3 outline-none focus:border-primary" />
              <input required type="email" name="email" placeholder="Seu e-mail" maxLength={255} className="rounded-xl border border-input bg-background px-4 py-3 outline-none focus:border-primary" />
            </div>
            <textarea required name="mensagem" rows={5} placeholder="Sua mensagem" maxLength={1000} className="w-full rounded-xl border border-input bg-background px-4 py-3 outline-none focus:border-primary" />
            <button disabled={sending} className="w-full rounded-full bg-primary py-3.5 font-medium text-primary-foreground transition hover:opacity-90 disabled:opacity-60">
              {sending ? "Enviando..." : "Enviar mensagem"}
            </button>
          </form>
          <div className="reveal mt-10 flex justify-center gap-4">
            {[[Github, "GitHub"], [Linkedin, "LinkedIn"], [Instagram, "Instagram"]].map(([Icon, label]) => {
              const I = Icon as typeof Github;
              return (
                <a key={label as string} href="#contato" aria-label={label as string} title={`${label} — em breve`} className="grid h-12 w-12 place-items-center rounded-full border border-gold/60 text-gold transition hover:-translate-y-1 hover:bg-primary hover:text-primary-foreground">
                  <I size={18} />
                </a>
              );
            })}
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-6 text-sm text-muted-foreground md:flex-row md:justify-between">
          <p>© {new Date().getFullYear()} · Desenvolvido por <span className="text-foreground">Julia Gabriela Cariaga</span>.</p>
          <div className="flex flex-wrap justify-center gap-5">
            {nav.map(([id, label]) => <a key={id} href={`#${id}`} className="hover:text-primary">{label}</a>)}
          </div>
        </div>
      </footer>
    </div>
  );
}
