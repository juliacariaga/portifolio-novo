import cyber from "@/assets/proj-cyber.jpg";
import pet from "@/assets/proj-pet.jpg";
import velha from "@/assets/proj-velha.jpg";
import web from "@/assets/proj-web.jpg";
import moda from "@/assets/proj-moda.jpg";
import unhas from "@/assets/proj-unhas.jpg";

export type Project = {
  number: string;
  title: string;
  tag: string;
  description: string;
  tech: string[];
  image: string;
  link?: string;
};

// Para adicionar um novo projeto, basta incluir um novo item nesta lista.
export const projects: Project[] = [
  {
    number: "01",
    title: "Cyber Clash",
    tag: "Banco de dados",
    description:
      "Modelagem de banco de dados inspirada em um jogo, com criação de tabelas, organização das informações e desenvolvimento de um Modelo Entidade-Relacionamento (MER).",
    tech: ["MER", "Modelagem", "SQL"],
    image: cyber,
  },
  {
    number: "02",
    title: "Pet Shop Game",
    tag: "Jogo",
    description:
      "Jogo interativo em que o usuário escolhe animais de estimação e realiza diferentes interações e cuidados.",
    tech: ["HTML5", "CSS3", "JavaScript"],
    image: pet,
  },
  {
    number: "03",
    title: "Jogo da Velha em Batalhas",
    tag: "Jogo",
    description:
      "Jogo da velha com identidade visual moderna, utilizando cores escuras e azuis.",
    tech: ["HTML5", "CSS3", "JavaScript"],
    image: velha,
  },
  {
    number: "04",
    title: "Atelier Rosé — Loja de Roupas",
    tag: "Empresa · Moda",
    description:
      "Ideia de loja de roupas inovadora: provador virtual, peças sustentáveis e coleções montadas a partir do estilo de cada cliente, com uma loja online elegante.",
    tech: ["HTML5", "CSS3", "JavaScript", "Identidade visual"],
    image: moda,
  },
  {
    number: "05",
    title: "Lumière Nail Studio",
    tag: "Empresa · Beleza",
    description:
      "Ideia de estúdio de unhas inovador: agendamento pelo celular, catálogo de nail art e simulação das cores nas mãos da cliente antes do atendimento.",
    tech: ["Criação de layouts", "Interfaces", "JavaScript"],
    image: unhas,
  },
  {
    number: "06",
    title: "Projetos Web",
    tag: "Sites",
    description:
      "Espaço para outros sites, atividades e experiências desenvolvidas durante meu aprendizado em Tecnologia da Informação.",
    tech: ["HTML5", "CSS3", "JavaScript"],
    image: web,
  },
];
